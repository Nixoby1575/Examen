using System;

namespace Program {
public class HeladoRomPasas : HeladoBase
{
    public override double CalculoTotalPrecio()
    {
        Console.Write("Total del Helado: ");
        var IceCream2 = 2.50;
        return IceCream2;
    }
}
}