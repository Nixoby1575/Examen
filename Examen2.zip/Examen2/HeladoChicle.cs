using System;

namespace Program {
public class HeladoChicle : HeladoBase
{
    public override double CalculoTotalPrecio()
    {
        Console.Write("Total del Helado: ");
        var IceCream1 = 3.25;
        return IceCream1;
    }
}
}
