using System;

namespace Program {
public class HeladoFresa : HeladoBase
{
    public override double CalculoTotalPrecio()
    {
        Console.Write("Total del Helado: ");
        var IceCream3 = 1.75;
        return IceCream3;
    }
}
}

