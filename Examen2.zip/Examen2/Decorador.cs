using System;

namespace Program {
public class Decorador : HeladoBase
{
    protected HeladoBase orden;
    public Decorador (HeladoBase orden)
    {
        this.orden = orden;
        
    }

    public override double CalculoTotalPrecio()
    {
        return orden.CalculoTotalPrecio();
    }

}
}