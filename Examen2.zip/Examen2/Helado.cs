using System;

namespace Program {
    public class Helado{
    
    public string Name {get; set;}
    public double Price {get; set;}

    }
}