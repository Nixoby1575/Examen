using System;

namespace Program {
public abstract class HeladoBase{
    public abstract double CalculoTotalPrecio();
    }
}






